package MqttServer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MqttDao {
//	public static final String TOPIC_HOUSE_REG 		= "house/register";
//	public static final String TOPIC_HOUSE_UPDATE   = "house/update";
//	public static final String TOPIC_HOUSE_DELETE 	= "house/delete";
//	public static final String TOPIC_HOUSE_GET 		= "house/get";
    public  PreparedStatement statement;
    public  Connection sqlConn;
    
    public MqttDao(){	        
    }
    
    public int sqlOpen(String host, String user, String password){
    	try{
    	  String myDriver = "org.gjt.mm.mysql.Driver";
    	  String myUrl = "jdbc:mysql://localhost/REGISTER";
    	  Class.forName(myDriver);
    	  sqlConn = DriverManager.getConnection(myUrl, user, password);
    	}
    	catch (Exception e){
    		e.printStackTrace();
    		return -1;
    	}
    	return 0;
    }
    
    /**
     * Close connection to database SQL server.
     * @return
     * 		-1 Failed.
     * 	 	 0 Success.
     */
    public int sqlClose(){
    	try{
    		sqlConn.close();
    	}
    	catch (Exception e){
    		e.printStackTrace();
    		return -1;
    	}
    	return 0;
    }
    
    /**
     * Create a new table on SQL server.
     * @return
     * 		-1 Failed.
     * 	 	 0 Success.
     */
    public int sqlCreateTable(String table){
    	try{
	    	Statement st = sqlConn.createStatement();
		      
	    	String sql = "CREATE TABLE " + table + " " +
						 "(ID INTEGER not NULL, " +
						 " UserName VARCHAR(255), " + 
						 " PassWord VARCHAR(255), " +
						 " MAC_Add VARCHAR(255), " +
						 " PRIMARY KEY ( ID ))";
    		st.executeUpdate(sql);
    	}
    	catch (Exception e){
    		//e.printStackTrace();
      	  	return -1;
      	}

    	return 0;
    }
    
    /**
     * Remove a table from database on SQL server.
     * @return
     * 		-1 Failed.
     * 	 	 0 Success.
     */
    public int sqlRemoveTable(String table){
    	

    	return 0;
    }
    
    /**
     * Add a new row of data to existing table on SQL server.
     * @return
     * 		-1 Failed.
     * 	 	>0 Row ID.
     */

    public int sqlTableAddRow(String table, String[] data){
    	try{
    		//PreparedStatement pt = null;
        	sqlConn.setAutoCommit(false);
    		System.out.println(data[0]);
    		System.out.println(data[1]);
    		System.out.println(data[2]);
    		//System.out.println(data[3]);
			//String sql = "INSERT INTO " + table +" VALUES (?,?,?,?)";
			String sql ="INSERT INTO " + table +" (UserName,PassWord,MAC_Add) VALUES(?,?,?)";
			PreparedStatement pt = sqlConn.prepareStatement(sql);
			//pt.setInt(1, Integer.parseInt(data[0]));
			pt.setString(1, data[0]);
			pt.setString(2, data[1]);
			pt.setString(3, data[2]);
			pt.executeUpdate();
			sqlConn.commit();
			
    	}
    	catch (Exception e){
    		e.printStackTrace();
      	  	return -1;
      	}		
    	return 0;
    }


    /**
     * Remove a row of data from existing table on SQL server.
     * @return
     * 		-1 Failed.
     * 	 	 0 Success.
     * @throws SQLException 
     */
    public void sqlTableRemoveRow(String MAC_Add) throws SQLException{
    	PreparedStatement pst = null;
    	sqlConn.setAutoCommit(false);
    	try{
    		String sql = "DELETE FROM Register_House " +
    					 "WHERE MAC_Add = ?";
    		
    		pst = sqlConn.prepareStatement(sql);
    		pst.setString(1,MAC_Add);
    		pst.executeUpdate();
    		sqlConn.commit();
    		
    	} catch(SQLException ex){
    		sqlConn.rollback();
    		throw ex;
    		
    	}
    	//"DELETE FROM TABLE WHERE id = ID";
    	
    }
    
    public int updateData(String userName, String passWord, String MacAddr) throws SQLException {
    
//    	System.out.println(userName);
//    	System.out.println(passWord);
//    	System.out.println(MacAddr);;
    	PreparedStatement pst = null;
    	sqlConn.setAutoCommit(false);
    	int result=0;
    	try {
    		String sql = 
    				" UPDATE Register_House " +
    				" SET UserName = ? ," +
    				" PassWord = ? " +
    				" WHERE MAC_Add = ?";
			pst = sqlConn.prepareStatement(sql);
			System.out.println("Macadd= "+MacAddr);
			pst.setString(1, userName);
			pst.setString(2, passWord);
			pst.setString(3, MacAddr);
			result=pst.executeUpdate();
			sqlConn.commit();
			
    		
    	}catch(SQLException ex) {
    		ex.printStackTrace();
    		sqlConn.rollback();
   		//throw ex;
    		
    	} finally {
			if (pst != null) pst.close();
		} 	
    	return result;
	}
    /*Lay thong tin nguoi dung gom UserName,PassWord
     * Dua vao thong tin nguoi dung 
     */
    public int getIm( String MAC_Add) throws SQLException{
    	try{
    		PreparedStatement pst = null;
    		ResultSet rs = null;
        	sqlConn.setAutoCommit(false);
        	String sql = "SELECT  UserName,PassWord FROM Register_House WHERE MAC_Add = ? ";
        	pst = sqlConn.prepareStatement(sql);
        	pst.setString(1,MAC_Add);
        	rs = pst.executeQuery();
        	
        	while(rs.next()) {
        		String UserName = rs.getString("UserName");
        		String PassWord = rs.getString("PassWord");
        		
        		System.out.println("UserName :" + MAC_Add);
        		System.out.println("PassWord :" + PassWord);
        	}
        	rs.close();
			sqlConn.commit();
			
    	}catch(SQLException ex){
    		sqlConn.rollback();
    		//throw ex;
    	}
    	return 0;
    	
    }
}





