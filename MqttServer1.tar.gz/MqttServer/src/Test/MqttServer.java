package Test;
import MqttServer.MqttDao;
import java.sql.Connection;
import java.sql.PreparedStatement;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;



public class MqttServer {
	public static final String TOPIC_HOUSE_REG 		= "house/register";
	public static final String TOPIC_HOUSE_UPDATE   = "house/update";
	public static final String TOPIC_HOUSE_DELETE 	= "house/delete";
	public static final String TOPIC_HOUSE_GET 		= "house/get";
    public  PreparedStatement statement;
    public  Connection sqlConn;
    
    
    public static void main(String[] args) {

    	MqttServer mqtt = new MqttServer();
    	mqtt.run();
    	
    }
    
    public MqttServer(){	        
    }
    
    public void run(){
        String broker       = "tcp://localhost:1883";
        String clientId    =   MqttClient.generateClientId();
        
        MqttDao mqttDao = new MqttDao();
   
        // Open connection to database server
       mqttDao.sqlOpen("localhost","root", "");
       
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            final MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            System.out.println("Connecting to broker: "+broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");
           
            /*----------------GOI HAM CALLBACK---------------------*/
             sampleClient.setCallback(new MqttCallback() { 
           
            	    public void connectionLost(Throwable cause) { 
            	     System.out.println("connectionLost-----------1" + cause); 
            	    } 
            	    public void deliveryComplete(IMqttDeliveryToken token) { 
            	     System.out.println("deliveryComplete---------2" + token.isComplete()); 
            	    } 
            	    public void messageArrived(String topic, MqttMessage arg1) 
            	      throws Exception { 
            	     System.out.println("messageArrived----------3 " + topic +"  "+arg1.toString());
            	     
            	     switch(topic){
            	     /*Dang ky them nha moi 
            	      * ID House duoc Server cap tu dong
            	      * Du lieu data gom UserName,passWord, MAC_Add
            	      * */
        	    	 case TOPIC_HOUSE_REG:
        	    		 System.out.println("->register house :" + arg1);
        	    		 
        	    		 String[] data = arg1.toString().split(";");
        	    		 
        	    		 if(data.length <3)
        	    			 break;
        	    		 
        	    		// String[] datas = new String[(data.length) +1];
        	    		 
//        	    		 datas[0] = Integer.toString(id_counter++);
//        	    		 System.out.println("id = "+id_counter);
//        	    		 for(int i = 0; i < data.length; i++){
//        	    			 datas[i+1] = data[i];
//        	    		 }
//        	    	       
        	    		 //mqttDao.sqlCreateTable("Register_House");
        	    		   //sqlTableAddRow("HouseReg", new String[]{"1", "Name", "Tuan", "String"});
        	    		  //sqlTableAddRow("HouseReg", new String[]{"2", "Year", "2011", "Integer"});
        	    		 // sqlTableAddRow("HouseReg", new String[]{"3", "Price", "100 mil", "String"});
        	    		  //mqttDao.sqlTableAddRow("Register_House", datas);
        	    		 mqttDao.sqlTableAddRow("Register_House", data);
        	    		  System.out.println("Register success");
        	    		  
        	    		 break;
        	    		 /* Update  lai du lieu vao Database
        	    		  * UserName,PassWord update du lieu moi dua vao dia chi MAC cua GateWay
        	    		  */
        	    	 case TOPIC_HOUSE_UPDATE:
        	    		 System.out.println("->update house: " + arg1);
        	    		 
        	    		 String[] dataRetrieve = arg1.toString().split(";");
        	    		 
        	    		 if (dataRetrieve.length < 3 ) break;
        	    		 
        	    		 int flg = mqttDao.updateData(dataRetrieve[0], dataRetrieve[1], dataRetrieve[2]);
        	    		 if (flg !=0){
        	    			System.out.println("Update success");
       	    		      }
        	    		 else 
        	    			 System.out.println("Update fail");
        	    		 break;
        	    		 
//        	    	 case TOPIC_HOUSE_DELETE:
//        	    		 System.out.println("->delete house :" + arg1);
//        	    		 String[] data_del =arg1.toString().split(";"); 
//        	    		 if (data_del.length < 3) break;
//        	    		 System.out.println(data_del);
//        	    		 mqttDao.sqlTableRemoveRow(data_del[0]);
//        	    		 System.out.println("Delete Success");
//        	    		 
////        	    		 break;
        	    	 case TOPIC_HOUSE_GET:
        	    		 System.out.println("get house:" + arg1);
        	    		 String dataget = arg1.toString();
        	    		 //if (dataget.length < 3) break;
        	    		 mqttDao.getIm(dataget);
        	    		 System.out.println("Get success");
        	    		 break;
        	    	 default:
        	    		 System.out.println("Fail");
        	    		 break;
        	    	 
        	    	 }
            	    }
					
					
            	   });
            
  
            sampleClient.subscribe(TOPIC_HOUSE_REG);
            sampleClient.subscribe(TOPIC_HOUSE_UPDATE);
            sampleClient.subscribe(TOPIC_HOUSE_DELETE);
            sampleClient.subscribe(TOPIC_HOUSE_GET);
        } catch(MqttException me) {
            System.out.println("reason "+me.getReasonCode());
            System.out.println("msg "+me.getMessage());
            System.out.println("loc "+me.getLocalizedMessage());
            System.out.println("cause "+me.getCause());
            System.out.println("excep "+me);
            me.printStackTrace();
        }
   //mqttDao.sqlClose();
        //return rs;
        // Disconnect to database server
        //mqttDao.sqlClose();
    } 
    
}



